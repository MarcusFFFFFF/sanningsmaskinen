import streamlit as st
import textwrap

st.set_page_config(
    page_title="Sanningsmaskinen",
    page_icon="🧠",
    layout="wide",
)

ACCENT = "#4ec994"
BG = "#0b111a"
PANEL = "#0f1722"
PANEL_2 = "#0c121a"
PANEL_3 = "#101827"
BORDER = "#2a3441"
TEXT = "#f5f7fb"
MUTED = "#aab4c3"
DANGER = "#ff6b6b"

st.markdown(f"""
<style>
html, body, .stApp {{
    background: {BG};
    color: {TEXT};
}}
.block-container {{
    max-width: 1100px;
}}
.hero {{
    background: {PANEL};
    padding: 30px;
    border-radius: 18px;
    border: 1px solid {BORDER};
}}
.card {{
    background: {PANEL_2};
    padding: 20px;
    border-radius: 16px;
    border: 1px solid {BORDER};
    margin-bottom: 15px;
}}
.red {{
    background: rgba(255, 107, 107, 0.08);
    border: 1px solid rgba(255, 107, 107, 0.3);
}}
</style>
""", unsafe_allow_html=True)

if "query" not in st.session_state:
    st.session_state.query = ""

def build_demo_result(q):
    return {
        "question": q,
        "headline": "Ukrainska militära aktörer är mest sannolika (95%).",
        "confidence": 95,
        "insight": "Sabotaget eliminerade möjligheten att återuppta rysk gasleverans.",
        "h": [
            ("H1", "STRUKTURELL", 95, "System, resurser, maktbalans"),
            ("H2", "INRIKESPOLITIK", 57, "Koalitioner, valintressen"),
            ("H3", "AKTÖRSPSYKOLOGI", 20, "Individuella beslut"),
        ],
        "primary": [
            "Explosioner skadade Nord Stream.",
            "Internationellt vatten.",
            "Tysk rättsprocess pågår.",
        ],
        "revised": [
            "H1 stärks av ny data.",
            "H2 kvarstår som sekundär.",
            "H3 försvagas.",
        ],
        "red": "Det finns fortfarande osäkerhet kring statlig kontroll.",
        "sources": [
            ("AP News", "https://apnews.com"),
            ("Der Spiegel", "https://spiegel.de"),
        ]
    }

st.title("Sanningsmaskinen")

st.markdown("""
<div class='hero'>
<h2>Förstå komplexa frågor på minuter</h2>
<p style='color:#aab4c3'>Analyserar hypoteser, evidens och konflikter.</p>
</div>
""", unsafe_allow_html=True)

col1, col2 = st.columns([5,1])

with col1:
    q = st.text_input("Fråga", value=st.session_state.query)

with col2:
    run = st.button("Analysera", key="run_btn")

if run and q:
    st.session_state.query = q

if st.session_state.query:
    r = build_demo_result(st.session_state.query)

    st.subheader(r["question"])
    st.markdown(f"## {r['headline']}")
    st.progress(r["confidence"])
    st.write(r["insight"])

    st.markdown("### Hypoteser")
    cols = st.columns(3)

    for col, (id_, label, score, title) in zip(cols, r["h"]):
        with col:
            st.markdown("<div class='card'>", unsafe_allow_html=True)
            st.caption(id_)
            st.markdown(f"**{label}**")
            st.write(title)
            st.progress(score)
            st.markdown("</div>", unsafe_allow_html=True)

    c1, c2 = st.columns(2)

    with c1:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Primär analys")
        for p in r["primary"]:
            st.write("•", p)
        st.markdown("</div>", unsafe_allow_html=True)

    with c2:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Reviderad analys")
        for p in r["revised"]:
            st.write("•", p)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<div class='card red'>", unsafe_allow_html=True)
    st.markdown("### Red Team")
    st.write(r["red"])
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("### Källor")
    for name, link in r["sources"]:
        st.markdown(f"- [{name}]({link})")

    export_text = textwrap.dedent(f"""
    Fråga: {r['question']}
    Slutsats: {r['headline']}
    Säkerhet: {r['confidence']}%
    """)

    st.download_button(
        "Ladda ner",
        export_text,
        file_name="analysis.txt",
        key="download_btn"
    )
