# -*- coding: utf-8 -*-
"""
SANNINGSMASKINEN — PDF Export v14.0
Final demo quality. Premium intelligence brief.
Priority: Authority > Clarity > Completeness
"""
import re, io
from datetime import date
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

_FD = "/usr/share/fonts/truetype/dejavu"
_ok = False
try:
    pdfmetrics.registerFont(TTFont("DV",  f"{_FD}/DejaVuSans.ttf"))
    pdfmetrics.registerFont(TTFont("DVB", f"{_FD}/DejaVuSans-Bold.ttf"))
    pdfmetrics.registerFont(TTFont("DVI", f"{_FD}/DejaVuSans-Oblique.ttf"))
    _ok = True
except Exception:
    pass

BODY  = "DV"  if _ok else "Helvetica"
BOLD  = "DVB" if _ok else "Helvetica-Bold"
ITAL  = "DVI" if _ok else "Helvetica-Oblique"
MONO  = "Courier"
MONOB = "Courier-Bold"

BG    = colors.HexColor("#0b0f14")
BG2   = colors.HexColor("#111820")
BG3   = colors.HexColor("#16202c")
RULE  = colors.HexColor("#1e2d3d")
RULE2 = colors.HexColor("#253448")
INK   = colors.HexColor("#e4ddd2")
INK2  = colors.HexColor("#a89f92")
INK3  = colors.HexColor("#5e6e80")
GRN   = colors.HexColor("#3ec98a")
GDIM  = colors.HexColor("#0c2318")
AMB   = colors.HexColor("#c9913e")
ADIM  = colors.HexColor("#231900")
RED   = colors.HexColor("#c85252")
RDIM  = colors.HexColor("#200c0c")

W, H     = A4
ML       = 48
MR       = W - 48
TW       = MR - ML
SEC_GAP  = 30
EL_GAP   = 13
PAD      = 14
FLOOR_P1 = 50
FLOOR_P2 = 50
FLOOR_P3 = 50


# ═══════════════════════════════════════════════════════════════════════════════
# CONTENT EXTRACTION
# ═══════════════════════════════════════════════════════════════════════════════

_NOISE = re.compile(
    r"^(?:"
    # AI/process language
    r"I'?ll search|let me search|I will search|searching for|"
    r"jag börjar|jag söker|låt mig söka|jag ska|"
    r"denna analys|this analysis|denna rapport|"
    # Engine headers
    r"SANNINGSMASKINEN\s+v\d|Datum:\s+20\d\d|"
    r"STATUS:\s+(?:PÅGÅENDE|KLAR|REVIDERAD|ONGOING)|"
    r"KONFIDENSGRAD:|REVIDERAD VERSION|LÄGESRAPPORT|"
    r"DAG\s+\d+\s*\||IRAN HAR DE FACTO KONTROLL\s*\.?\s*$|"
    r"INSTRUKTION:|INTEGRERA DESSA|BREAKING\s*—\s*SENASTE|"
    # Pågående/tidskänslig markers
    r"\[PÅGÅENDE|PÅGÅENDE\s*—|tidskänslig|ny deadline|"
    # Claude/system references
    r"claude|claude:s|gpt|analysmotor|pipeline|"
    r"primäranalysen håller inte|analysen håller inte|"
    # Internal verdict phrasing
    r"claude:s analys|min analys|vår analys"
    r")",
    re.IGNORECASE
)

def _clean(txt):
    if not txt: return ""
    t = str(txt)
    t = re.sub(r'\[([^\]]+)\]\(https?://[^\)]+\)', r'\1', t)
    t = re.sub(r'https?://\S+', '', t)
    t = re.sub(r'\*{1,3}', '', t)
    t = re.sub(r'^#{1,6}\s*', '', t, flags=re.MULTILINE)
    # Remove bracketed engine tags
    t = re.sub(r'\[(?:FAKTA|INFERENS|DEBATTERAD TOLKNING|PÅGÅENDE[^\]]*|HYPOTETISKT|REVIDERAD VERSION)\]',
               '', t, flags=re.I)
    t = re.sub(r'[⚡🚨🔴📊🔍🧠⚠️🏆💥🟢🔵◈◉◇▸›•·■●◎⟳◷▲]', '', t)
    # Remove engine status lines embedded in text
    t = re.sub(r'#\s*[A-ZÅÄÖ\s]+—\s*LÄGESRAPPORT[^\n]*', '', t)
    t = re.sub(r'STATUS:\s*[A-ZÅÄÖ\s—]+\n', '', t, flags=re.I)
    return t.strip()

def _ok_line(s):
    s = s.strip()
    return (bool(s) and len(s) > 10
            and not _NOISE.match(s)
            and not (s.startswith('|') and s.count('|') >= 2))

def _trunc(txt, n):
    t = _clean(txt)
    if not t: return ""
    if len(t) <= n: return t
    chunk = t[:n]
    for m in reversed(list(re.finditer(r'[.!?]\s', chunk))):
        if m.end() > n * 0.42: return t[:m.end()].rstrip()
    sp = chunk.rfind(' ')
    return (t[:sp] if sp > n * 0.4 else chunk).rstrip() + '…'

def _sentences(text, min_l=35, max_l=260):
    for s in re.split(r'(?<=[.!?])\s+', _clean(text)):
        s = s.strip()
        if min_l <= len(s) <= max_l and _ok_line(s):
            yield s

def _first_sent(text, min_l=35, max_l=260):
    return next(_sentences(text, min_l, max_l), "")

# ── HERO: answers the question directly — concrete real-world status ──────────
def _get_hero(r):
    if r.get("_hero_override"):
        return _trunc(r["_hero_override"], 185)

    # Prefer sentences that directly answer "what is the status"
    STATUS_WORDS = re.compile(
        r'(?:är|blockerad|stängt|öppet|kontrollerar|pågår|bekräftad|'
        r'genomförde|utförde|sprängde|ockuperar|invaderade|styr|håller)',
        re.IGNORECASE
    )
    AVOID = re.compile(
        r'^(?:frågan är|det är oklart|osäkerheten|ingen har bevisat|'
        r'vi vet inte|fullständig tillskrivning|trots|dock|men |'
        r'although|however|the question|no one|jag |denna analys)',
        re.IGNORECASE
    )

    # Try article first — first status-affirming sentence
    art = r.get("article","")
    for s in _sentences(art, 45, 200):
        if not AVOID.match(s) and STATUS_WORDS.search(s):
            return _trunc(s, 185)

    # Try H1 tes
    ranked = r.get("ranked") or []
    if ranked:
        tes = _clean(ranked[0].get("tes",""))
        s   = _first_sent(tes, 40, 200)
        if s and not AVOID.match(s):
            return _trunc(s, 185)

    # Fallback: first clean sentence anywhere
    for src in [art, r.get("insight",""), r.get("final_analysis","")]:
        for s in _sentences(src or "", 35, 200):
            if not AVOID.match(s):
                return _trunc(s, 185)
    return ""

# ── KEY INSIGHT: mechanism — HOW the situation works ─────────────────────────
def _get_key_insight(r, hero=""):
    if r.get("_insight_override"):
        return _trunc(r["_insight_override"], 170)

    # Prefer sentences explaining mechanism/how
    MECH = re.compile(
        r'(?:genom|med hjälp av|via|utövas|fungerar|mekanismen|'
        r'innebär|kontroll(?:en)? utövas|selektiv|asymmetrisk|'
        r'hävstång|avgörande|drivs av|strukturellt)',
        re.IGNORECASE
    )
    hero_key = (hero or "")[:50].lower()
    ins      = _clean(r.get("insight",""))
    ranked   = r.get("ranked") or []

    # 1. Mechanism sentence from insight
    for s in _sentences(ins, 40, 170):
        if s.lower()[:40] not in hero_key and MECH.search(s):
            return _trunc(s, 160)

    # 2. Any sentence from insight differing from hero
    for s in list(_sentences(ins, 35, 170))[1:]:
        if s.lower()[:40] not in hero_key and _ok_line(s):
            return _trunc(s, 160)

    # 3. Mechanism sentence from H1 tes (second sentence)
    if ranked:
        for s in list(_sentences(_clean(ranked[0].get("tes","")), 35, 170))[1:]:
            if s.lower()[:40] not in hero_key:
                return _trunc(s, 160)

    # 4. From article/final_analysis
    for src in [r.get("article",""), r.get("final_analysis","")]:
        for s in _sentences(src or "", 40, 170):
            if s.lower()[:40] not in hero_key and MECH.search(s):
                return _trunc(s, 160)
    return ""

# ── BREAKING ─────────────────────────────────────────────────────────────────
def _get_breaking(r):
    txt   = (r.get("claude_answer") or "") + "\n" + (r.get("final_analysis") or "")
    items, seen = [], set()
    for line in txt.split('\n'):
        s = line.strip()
        m = re.match(r'^(?:#{1,3}\s*)?BREAKING\s*\d*\s*[:\-—]\s*(.+)', s, re.I)
        if m:
            item = _trunc(_clean(m.group(1)), 115)
            if item and _ok_line(item) and item not in seen:
                seen.add(item); items.append(item)
        if len(items) >= 4: break
    if not items:
        in_b = False
        for line in txt.split('\n'):
            s = line.strip()
            if re.search(r'SENASTE\s+TIMMARNAS|BREAKING\s+CONTEXT', s, re.I):
                in_b = True; continue
            if in_b:
                if re.match(r'^#{1,3}\s+[A-ZÅÄÖ]', s): break
                item = _trunc(_clean(s), 115)
                if len(item) > 32 and _ok_line(item) and item not in seen:
                    seen.add(item); items.append(item)
            if len(items) >= 4: break
    return items[:4]

# ── SNAPSHOT 2×2 — short, scannable, real-world language ─────────────────────
def _get_snapshot(r):
    ranked = r.get("ranked") or []
    op     = r.get("operativ") or {}
    rc_st  = (r.get("reality_check") or {}).get("status","")

    # LÄGE — max ~25 chars, plain status
    nu = _trunc(_clean(op.get("nu","")), 30)
    # Strip trailing "…" and clean
    nu = re.sub(r'[—\-]\s*se\s+full\w+.*$', '', nu, flags=re.I).strip().rstrip('…').strip()
    if not nu or not _ok_line(nu) or len(nu) < 5:
        nu = {"VERIFIED":"Bekräftad","ONGOING":"Pågående situation",
              "PARTIAL":"Delvis bekräftad","ANALYTICAL":"Strukturell fråga",
              "HYPOTHETICAL":"Hypotetisk"}.get(rc_st, "Under analys")

    # PRIMÄR AKTÖR — at most 3–4 meaningful words, not a sentence
    aktör = _trunc(_clean(r.get("_aktör_override","")), 35)
    if not aktör and ranked:
        # Extract actor: prefer label/title subject, not full tes
        title = _clean(ranked[0].get("title",""))
        # Take first 3 meaningful words from title
        words = [w for w in title.split() if len(w) > 2][:3]
        aktör = " ".join(words)
    if not aktör or not _ok_line(aktör):
        aktör = "Ej fastställd"
    # Ensure it's short — no sentences
    aktör = aktör.split('.')[0].split(',')[0][:35].strip()

    # BEVISSTYRKA — correct styrka→label mapping
    ev = "Otillräcklig"
    if ranked:
        styrka = (ranked[0].get("styrka") or "MEDEL").upper()
        pct    = int(ranked[0].get("conf_pct", int(ranked[0].get("conf",0.5)*100)))
        # Correct mapping: HÖG = Hög (not Stark to avoid mismatch)
        ev_lbl = {"HÖG":"Hög","MEDEL-HÖG":"Medel–Hög","MEDEL":"Medel","LÅG":"Låg"
                  }.get(styrka, "Medel")
        ev = f"{ev_lbl} ({pct}%)"

    # RISKNIVÅ — single word or very short phrase
    risk = _trunc(_clean(op.get("risk","")), 30)
    risk = re.sub(r'\s*—.*$', '', risk).strip()   # strip explanation after dash
    if not risk or not _ok_line(risk) or len(risk) < 2:
        pct  = int(ranked[0].get("conf_pct",50)) if ranked else 50
        risk = "Hög" if pct >= 70 else "Medel" if pct >= 42 else "Låg"
    # Capitalize
    risk = risk[0].upper() + risk[1:] if risk else risk

    return [("LÄGE", nu), ("PRIMÄR AKTÖR", aktör), ("BEVISSTYRKA", ev), ("RISKNIVÅ", risk)]

# ── NARRATIVE PARAGRAPHS — strict noise filtering ────────────────────────────
def _get_paras(r, max_p=5):
    # Extra patterns that must never appear in narrative
    PARA_SKIP = re.compile(
        r'^(?:#{1,4}|BREAKING|SENASTE|TES\s*:|BEVIS|MOTARG|STYRKA|FALSIF|'
        r'\|---|H[1-4]\s*[\[\(]|STATUS:\s*[A-ZÅÄÖ]|DAG\s+\d+|'
        r'SELEKTIV\s+BLOCKAD|INTE\s+FULLSTÄNDIG|LÄGESRAPPORT)',
        re.I
    )
    def _para_ok(p):
        p = p.strip()
        return (len(p) > 55 and _ok_line(p)
                and not PARA_SKIP.match(p)
                and not re.match(r'^jag\s', p, re.I)
                and not re.match(r'^låt\s+mig\s', p, re.I))

    art = r.get("article","")
    if art and len(art.strip()) > 80:
        out = []
        for p in re.split(r'\n{2,}', _clean(art)):
            p2 = p.strip()
            if _para_ok(p2):
                out.append(_trunc(p2, 380))
        if len(out) >= 2: return out[:max_p]

    src  = r.get("final_analysis","") or r.get("claude_answer","")
    out, tot = [], 0
    for p in re.split(r'\n{2,}', src or ""):
        p2 = _clean(p).strip()
        if not _para_ok(p2): continue
        out.append(_trunc(p2, 340))
        tot += len(p2)
        if tot > 1000 or len(out) >= max_p: break
    return out

# ── SCENARIOS: 3 concrete real-world outcomes ────────────────────────────────
def _get_scenarios(r):
    ranked = r.get("ranked") or []

    # Fixed real-world outcome labels
    OUTCOME_LABELS = [
        "Statlig inblandning bekräftad",
        "Aktivistmodell bekräftad",
        "Alternativ aktör träder fram",
    ]

    out = []
    for i, h in enumerate(ranked[:3]):
        lbl  = OUTCOME_LABELS[i] if i < len(OUTCOME_LABELS) else f"Utfall {i+1}"
        # Get first clean sentence from tes — not falsification (often conditional)
        tes  = _first_sent(_clean(h.get("tes","")), 30, 105)
        # Filter noise aggressively
        if not tes or not _ok_line(tes):
            tes = _trunc(_clean(h.get("title", h.get("label",""))), 100)
        if tes and _ok_line(tes):
            out.append((lbl, tes))

    # Ensure exactly 3 — pad with generic if needed
    while len(out) < 3:
        i = len(out)
        out.append((OUTCOME_LABELS[i] if i < 3 else f"Utfall {i+1}",
                    "Se djupanalys för detaljer."))
    return out[:3]

# ── VERDICT — clean external language, zero internal references ───────────────
def _get_verdict(r):
    txt = r.get("red_team_report","") or ""
    m   = re.search(r'VERDICT[:\s]+([^\n]+)', txt, re.I)
    if not m: return ""
    raw = re.sub(r'\*+','', m.group(1)).strip()
    orig_upper = raw.upper()

    # Strip internal verdict word completely
    raw = re.sub(r'^(?:KOLLAPSAR|MODIFIERAS|HÅLLER|JUSTERAS)[^—.]*[—.]?\s*', '', raw, flags=re.I).strip()
    # Remove any remaining internal/AI references
    raw = re.sub(r'claude[:\s\'s]*analys[^\.\,]*[\.\,]?', '', raw, flags=re.I).strip()
    raw = re.sub(r'analysen håller inte[^\.\,]*[\.\,]?', '', raw, flags=re.I).strip()
    raw = re.sub(r'primäranalysen håller inte[^\.\,]*[\.\,]?', '', raw, flags=re.I).strip()

    # External prefix based on verdict type
    if "KOLLAPSAR" in orig_upper:
        prefix = "Alternativ tolkning är välgrundad och bör beaktas."
    elif "MODIFIERAS" in orig_upper:
        prefix = "Primäranalysen håller med reservation."
    else:
        prefix = "Bedömningen är välgrundad."

    raw = raw.strip().lstrip('—').strip()
    if raw and len(raw) > 15 and not _NOISE.match(raw):
        raw = raw[0].upper() + raw[1:]
        return _trunc(f"{prefix} {raw}", 165)
    return prefix

def _get_facts(r):
    txt  = (r.get("final_analysis","") or "") + "\n" + (r.get("claude_answer","") or "")
    FACT = [r'\d+\s*(?:%|procent|dollar|fat|miljoner|miljarder|dagar|månader)',
            r'(?:stängt|blockad|passage|ultimatum|deadline|transitering|explosion|arrest)',
            r'(?:trupper|fartyg|missil|attack|dömd|gripen)',
            r'(?:IRGC|BGH|DIA|IMF|NATO|FN\b|ICC|FBI|CIA)']
    items, seen = [], set()
    for line in txt.split('\n'):
        s = _clean(line).strip()
        if len(s) < 38 or len(s) > 170: continue
        if not _ok_line(s): continue
        if re.match(r'^(?:#{1,4}|TES|BEVIS|MOTARG|STYRKA|FALSIF|H[1-4]\s*[\[\(])', s, re.I): continue
        key = s[:42]
        if key in seen: continue
        if any(re.search(p, s, re.I) for p in FACT):
            seen.add(key); items.append(_trunc(s, 135))
        if len(items) >= 4: break
    return items

def _get_urls(r):
    txt = (r.get("claude_answer","") or "") + "\n" + (r.get("final_analysis","") or "")
    seen, out = set(), []
    BAD = {'google.com','google.se','bing.com','yahoo.com'}
    for u in re.findall(r'https?://[^\s\)\]"\'<]+', txt):
        u = u.rstrip('.,;):')
        d = re.sub(r'https?://(www\.)?','',u).split('/')[0]
        if d not in seen and not any(b in d for b in BAD):
            seen.add(d); out.append(d)
    return out[:5]

def _ccol(pct):
    if pct >= 65: return GRN
    if pct >= 40: return AMB
    return RED

def _cdim(pct):
    if pct >= 65: return GDIM
    if pct >= 40: return ADIM
    return RDIM


# ═══════════════════════════════════════════════════════════════════════════════
# CANVAS ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class Doc:
    def __init__(self, buf):
        self.cv = canvas.Canvas(buf, pagesize=A4)
        self.cv.setTitle("Sanningsmaskinen — Intelligence Brief")
        self._pg = 0

    def _f(self, f, sz):   self.cv.setFont(f, sz)
    def _fc(self, c):      self.cv.setFillColor(c)
    def _sc(self, c, lw):  self.cv.setStrokeColor(c); self.cv.setLineWidth(lw)
    def _sw(self, s, f, sz): return self.cv.stringWidth(str(s), f, sz)

    def T(self, x, y, s, sz, col, f=BODY, a='l'):
        self._f(f, sz); self._fc(col)
        {'r': self.cv.drawRightString,
         'c': self.cv.drawCentredString}.get(a, self.cv.drawString)(x, y, str(s))

    def W(self, x, y, txt, sz, col, f=BODY, mw=None, lh=None, floor=50, mx=99):
        """Strict wrap. Never below floor. Never beyond mx lines."""
        if not txt: return y
        if mw is None: mw = MR - x
        if lh is None: lh = round(sz * 1.45)
        self._f(f, sz); self._fc(col)
        words = str(txt).split(); line = ""; n = 0
        for w in words:
            test = (line + " " + w).strip()
            if self._sw(test, f, sz) > mw:
                if n >= mx or y < floor: return y
                if line: self.cv.drawString(x, y, line)
                y -= lh; n += 1; line = w
            else:
                line = test
        if line and n < mx and y >= floor:
            self.cv.drawString(x, y, line); y -= lh
        return y

    def HL(self, y, x1=None, x2=None, col=RULE, lw=0.4):
        self._sc(col, lw); self.cv.line(x1 or ML, y, x2 or MR, y)

    def RECT(self, x, y, w, h, fc, sc=None, lw=0.4):
        self._fc(fc)
        if sc: self._sc(sc, lw); self.cv.rect(x, y, w, h, fill=1, stroke=1)
        else:  self.cv.rect(x, y, w, h, fill=1, stroke=0)

    def LBAR(self, x, y1, y2, col, lw=3.5):
        self._sc(col, lw); self.cv.line(x, y1, x, y2)

    def DOT(self, x, y, r=2, col=INK3):
        self._fc(col); self.cv.circle(x, y, r, fill=1, stroke=0)

    def NP(self):
        if self._pg > 0: self._foot(); self.cv.showPage()
        self._pg += 1
        self.RECT(0, 0, W, H, BG)

    def _foot(self):
        today = date.today().strftime("%Y-%m-%d")
        self.HL(28, lw=0.3, col=RULE)
        self.T(ML, 17, f"Sanningsmaskinen  ·  Intelligence Brief  ·  {today}", 7, INK3, MONO)
        self.T(MR, 17, str(self._pg), 7, INK3, MONOB, 'r')

    def save(self): self._foot(); self.cv.save()

    def masthead(self, label, today, status=""):
        self.T(ML,      H-24, "SANNINGSMASKINEN", 8, INK3, MONOB)
        self.T(ML+116,  H-24, "·  INTELLIGENCE BRIEF", 8, INK3, MONO)
        self.T(MR,      H-24, today, 8, INK3, MONO, 'r')
        self.HL(H-31, lw=0.8, col=GRN)
        self.T(ML, H-42, label, 7, INK3, MONO)
        if status:
            ed = {"VERIFIED":"Bekräftad","ONGOING":"Pågående","PARTIAL":"Delvis bekräftad",
                  "ANALYTICAL":"Strukturell","HYPOTHETICAL":"Hypotetisk",
                  "REVIDERAD":"Reviderad","KLAR":"Avslutad"}.get(status.upper(), status)
            self.T(MR, H-42, ed, 7, INK3, MONO, 'r')
        return H - 60

    def section_label(self, y, label, col=INK3):
        self.T(ML, y, label, 7.5, col, MONOB)
        return y - 12

    def divider(self, y, gap_above=6, gap_below=SEC_GAP):
        y -= gap_above
        self.HL(y, lw=0.35, col=RULE2)
        return y - gap_below


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — DECISION PAGE
# ═══════════════════════════════════════════════════════════════════════════════

def build_p1(doc, r):
    doc.NP()
    today  = date.today().strftime("%Y-%m-%d")
    rc_st  = (r.get("reality_check") or {}).get("status","")
    doc_st = r.get("status","")
    ranked = r.get("ranked") or []
    FL     = FLOOR_P1

    y = doc.masthead("BESLUTSSIDA  ·  1 / 3", today, doc_st or rc_st)

    # ── QUESTION ──────────────────────────────────────────────────────────────
    q = _trunc(r.get("question",""), 92)
    y = doc.W(ML, y, q, 21, INK, BOLD, mw=TW, lh=27, floor=FL, mx=2)
    y -= EL_GAP
    doc.HL(y, lw=0.5, col=RULE2)
    y -= SEC_GAP

    # ── BREAKING ──────────────────────────────────────────────────────────────
    brk = _get_breaking(r)
    if brk and y > FL + 65:
        y = doc.section_label(y, "SENASTE TIMMARNA", RED)
        for item in brk:
            if y < FL + 28: break
            doc.DOT(ML+4, y+3.5, 2.2, RED)
            y = doc.W(ML+13, y, item, 9.5, INK2, BODY,
                      mw=TW-15, lh=14, floor=FL, mx=2)
            y -= 5
        y = doc.divider(y, gap_above=8, gap_below=SEC_GAP)

    # ── HERO ASSESSMENT — declarative conclusion, max 2 lines ────────────────
    hero = _get_hero(r)
    if hero and y > FL + 52:
        bh = PAD + 13 + 17*2 + PAD
        bh = min(bh, 78)
        doc.RECT(ML, y-bh, TW, bh, BG3)
        doc.LBAR(ML, y-bh, y, GRN, 4)
        doc.T(ML+PAD, y-12, "BEDÖMNING", 7, GRN, MONOB)
        doc.W(ML+PAD, y-26, hero, 11, INK, BOLD,
              mw=TW-PAD*2, lh=17, floor=y-bh+8, mx=2)
        y -= bh + SEC_GAP

    # ── KEY INSIGHT — interpretation, new angle, max 1–2 lines ──────────────
    insight = _get_key_insight(r, hero)
    if insight and y > FL + 28:
        doc.HL(y+4, lw=0.8, col=AMB)
        doc.T(ML, y-9,  "NYCKELINSIKT",  7, AMB, MONOB)
        doc.W(ML, y-23, insight, 9.5, AMB, ITAL,
              mw=TW, lh=14, floor=FL, mx=2)
        y -= 42
        y = doc.divider(y, gap_above=4, gap_below=SEC_GAP)

    # ── SNAPSHOT 2×2 GRID ────────────────────────────────────────────────────
    snap = _get_snapshot(r)
    if snap and y > FL + 52:
        cw  = (TW - 12) / 2
        rh  = 38
        for i, (lbl, val) in enumerate(snap[:4]):
            cx = ML if i % 2 == 0 else ML + cw + 12
            ry = y - (i // 2) * rh
            if ry < FL + 8: break
            doc.RECT(cx, ry-rh+4, cw, rh-2, BG2)
            doc.HL(ry-rh+4, x1=cx, x2=cx+3, col=GRN if i < 2 else AMB, lw=3)
            doc.T(cx+10, ry-14, lbl, 6.5, INK3, MONOB)
            doc.W(cx+10, ry-26, val, 9, INK, BOLD,
                  mw=cw-16, lh=13, floor=ry-rh+6, mx=1)
        y -= 2*rh + EL_GAP
        y = doc.divider(y, gap_above=4, gap_below=SEC_GAP)

    # ── HYPOTHESIS RANKING — compact single row: H1 — 72%   H2 — 48%   H3 — 22%
    if ranked and y > FL + 36:
        y = doc.section_label(y, "HYPOTES-RANKING")
        HCOLS = [GRN, AMB, RED]
        # Build compact row
        spacing = TW / 3
        for i, h in enumerate(ranked[:3]):
            if y < FL + 14: break
            col = HCOLS[i] if i < 3 else INK3
            pct = int(h.get("conf_pct", int(h.get("conf",0.5)*100)))
            key = h.get("key","")
            lbl = h.get("label","")
            cx  = ML + i * spacing
            # Key + dash + percent
            doc.T(cx, y,    f"{key} — {pct}%", 11, col, MONOB)
            # Category label below
            doc.T(cx, y-14, lbl, 7.5, INK3, MONO)
        y -= 30
        y = doc.divider(y, gap_above=8, gap_below=SEC_GAP)

    # ── OPERATIONAL CONCLUSION — decisive, external-facing ───────────────────
    # Override takes priority, then verdict, then operativ
    concl_override = r.get("_conclusion_override","")
    verdict  = _get_verdict(r)
    op       = r.get("operativ") or {}
    concl    = (
        _trunc(concl_override, 220) if concl_override else
        verdict or
        _trunc(_clean(op.get("nasta","")), 175) or
        _trunc(_clean(op.get("nu","")), 175)
    )
    if concl and y > FL + 22:
        y = doc.section_label(y, "SLUTSATS")
        doc.W(ML, y, concl, 10, INK2, ITAL, mw=TW, lh=15, floor=FL, mx=3)

    urls = _get_urls(r)
    if urls:
        doc.T(ML, 46, _trunc("  ·  ".join(urls), 125), 6.5, INK3, MONO)


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — NARRATIVE
# ═══════════════════════════════════════════════════════════════════════════════

def build_p2(doc, r):
    doc.NP()
    today = date.today().strftime("%Y-%m-%d")
    paras = _get_paras(r, max_p=5)
    scens = _get_scenarios(r)
    FL    = FLOOR_P2

    y = doc.masthead("NARRATIV  ·  2 / 3", today)

    doc.T(ML, y, "BAKGRUND & KONTEXT", 7.5, INK3, MONOB)
    doc.HL(y-9, lw=0.6, col=RULE2)
    y -= 22

    # Headline
    q = _trunc(r.get("question",""), 76)
    y = doc.W(ML, y, q, 19, INK, BOLD, mw=TW, lh=25, floor=FL, mx=2)
    y -= SEC_GAP

    # Intro — bold, max 3 lines
    if paras and y > FL + 60:
        y = doc.W(ML, y, paras[0], 10.5, INK, BOLD,
                  mw=TW, lh=16, floor=FL, mx=3)
        y -= EL_GAP + 4

    # Body paragraphs — max 4 lines each
    for para in paras[1:4]:
        if y < FL + 75: break
        y = doc.W(ML, y, para, 10, INK2, BODY,
                  mw=TW, lh=15, floor=FL+55, mx=4)
        y -= EL_GAP

    # Quote callout — override-fält har prioritet, annars auto-välj 1 mening
    quote_override = r.get("_quote_override","")
    if y > FL + 60:
        if quote_override and _ok_line(quote_override):
            quote = _trunc(quote_override, 140)
        else:
            hero_key = _get_hero(r)[:50].lower()
            quote    = ""
            for p in paras[1:]:
                s = _first_sent(p, 40, 140)
                if s and s.lower()[:40] not in hero_key:
                    quote = s; break
        if quote and _ok_line(quote):
            y -= 8
            q_floor = max(FL, y-55)
            doc.LBAR(ML+2, q_floor, y+4, AMB, 2.5)
            y = doc.W(ML+16, y, f'"{quote}"', 10, AMB, ITAL,
                      mw=TW-18, lh=15, floor=q_floor, mx=3)
            y -= SEC_GAP

    # Scenarios — concrete real-world outcomes
    if scens and y > FL + 52:
        doc.HL(y, lw=0.4, col=RULE); y -= SEC_GAP - 4
        y = doc.section_label(y, "MÖJLIGA UTFALL")
        SCOL = [GRN, AMB, RED]
        for i, (lbl, desc) in enumerate(scens):
            if y < FL + 14: break
            col = SCOL[i % 3]
            doc.DOT(ML+4, y+3.5, 2.5, col)
            doc.T(ML+14, y, lbl, 8.5, col, MONOB)
            y -= 13
            y = doc.W(ML+14, y, desc, 9, INK2, BODY,
                      mw=TW-16, lh=13, floor=FL, mx=2)
            y -= 10

    # No closing line — avoids duplication with hero/intro
    urls = _get_urls(r)
    if urls:
        doc.T(ML, 46, _trunc("  ·  ".join(urls), 125), 6.5, INK3, MONO)


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — DEEP ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

def build_p3(doc, r):
    doc.NP()
    ranked = r.get("ranked") or []
    today  = date.today().strftime("%Y-%m-%d")
    FL     = FLOOR_P3
    HCOLS  = [GRN, AMB, RED]

    y = doc.masthead("DJUPANALYS  ·  3 / 3", today)

    doc.T(ML, y, "HYPOTESANALYS", 7.5, INK3, MONOB)
    doc.HL(y-9, lw=0.6, col=RULE2)
    y -= 22

    # ── H1 / H2 / H3 — all four fields always present ────────────────────────
    for i, h in enumerate(ranked[:3]):
        if y < FL + 105: break
        col  = HCOLS[i] if i < 3 else INK3
        key  = h.get("key","")
        lbl  = h.get("label","")
        titl = _trunc(h.get("title", h.get("tes","")), 70)
        tes  = _trunc(h.get("tes",""), 220)
        bevs = [_trunc(_clean(b), 160) for b in (h.get("bevis") or [])[:3]
                if b and _ok_line(_clean(str(b)))]
        # Motarg — handle list or string
        mot_raw = h.get("motarg") or []
        if isinstance(mot_raw, list):
            mot_raw = mot_raw[0] if mot_raw else ""
        mot  = _trunc(_clean(str(mot_raw)), 125)
        # Falsifiering — strip engine noise tags strictly
        fals_raw = _clean(h.get("falsifiering",""))
        fals_raw = re.sub(r'\[PÅGÅENDE[^\]]*\]', '', fals_raw, flags=re.I).strip()
        fals_raw = re.sub(r'PÅGÅENDE\s*—[^\n]+', '', fals_raw, flags=re.I).strip()
        fals = _trunc(fals_raw, 95) if _ok_line(fals_raw) else ""
        pct  = int(h.get("conf_pct", int(h.get("conf",0.5)*100)))

        # Guaranteed fallbacks — never a blank field
        if not tes:   tes  = titl or "Hypotesen saknar specificerad tes."
        if not bevs:  bevs = ["Evidens ej specificerad i källmaterial."]
        if not mot:   mot  = "Inga identifierade motargument."
        if not fals:  fals = "Bevis som direkt motsäger hypotesens kärnantagande."

        # ── Header ───────────────────────────────────────────────────────────
        doc.RECT(ML, y-20, TW, 22, _cdim(pct))
        doc.LBAR(ML, y-20, y+2, col, 4)
        doc.T(ML+12, y-10, key,   10, col, MONOB)
        doc.T(ML+40, y-10, lbl,    8, col, MONO)
        doc.T(MR,    y-10, f"{pct}%", 10, col, MONOB, 'r')
        y -= 28

        # ── Title ─────────────────────────────────────────────────────────────
        y = doc.W(ML, y, titl, 12, INK, BOLD,
                  mw=TW*0.86, lh=17, floor=FL, mx=2)
        y -= 10

        # ── TES ───────────────────────────────────────────────────────────────
        doc.T(ML, y, "TES", 6.5, col, MONOB)
        y -= 11
        y = doc.W(ML+6, y, tes, 9.5, INK, BODY,
                  mw=TW-8, lh=14, floor=FL, mx=3)
        y -= EL_GAP

        # ── BEVIS ─────────────────────────────────────────────────────────────
        if bevs and y > FL + 34:
            doc.T(ML, y, "BEVIS", 6.5, GRN, MONOB)
            y -= 11
            for b in bevs:
                if not b or y < FL + 12: break
                doc.DOT(ML+5, y+3, 2, GRN)
                y = doc.W(ML+14, y, b, 9, INK2, BODY,
                          mw=TW-16, lh=13, floor=FL, mx=3)
                y -= 4
            y -= 6

        # ── MOTARGUMENT ───────────────────────────────────────────────────────
        if mot and y > FL + 28:
            doc.T(ML, y, "MOTARGUMENT", 6.5, AMB, MONOB)
            y -= 11
            y = doc.W(ML+6, y, mot, 9, INK2, ITAL,
                      mw=TW-8, lh=13, floor=FL, mx=3)
            y -= EL_GAP

        # ── FALSIFIERAS OM — max 2 lines ─────────────────────────────────────
        if fals and fals != "---" and y > FL + 20:
            doc.T(ML, y, "FALSIFIERAS OM", 6.5, INK3, MONOB)
            y -= 11
            y = doc.W(ML+6, y, fals, 8.5, INK3, ITAL,
                      mw=TW-8, lh=12, floor=FL, mx=2)
            y -= 6

        # ── Clear block separator — generous spacing ──────────────────────────
        y -= 14
        if i < 2:
            doc.HL(y, lw=0.7, col=RULE2)
            y -= SEC_GAP + 6   # extra breathing room between hypotheses

    # ── COMBINED RANKING ─────────────────────────────────────────────────────
    if ranked and y > FL + 68:
        doc.HL(y, lw=0.5, col=RULE2); y -= SEC_GAP
        y = doc.section_label(y, "SAMMANVÄGD RANKING")
        BAR_W = TW * 0.36
        for i, h in enumerate(ranked[:3]):
            if y < FL + 14: break
            pct = int(h.get("conf_pct", int(h.get("conf",0.5)*100)))
            col = HCOLS[i] if i < 3 else INK3
            doc.RECT(ML, y-13, 16, 15, _cdim(pct))
            doc.T(ML+8, y-9, str(i+1), 8, col, MONOB, 'c')
            doc.T(ML+22, y-2, f"{h.get('key','')}  {h.get('label','')}", 9, col, MONOB)
            bx = MR - BAR_W - 34
            doc.RECT(bx, y-5, BAR_W, 4, RULE)
            doc.RECT(bx, y-5, max(3, BAR_W*pct/100), 4, col)
            doc.T(MR, y-2, f"{pct}%", 10, col, MONOB, 'r')
            y -= 18

    # ── CONFIRMED FACTS ───────────────────────────────────────────────────────
    facts = _get_facts(r)
    if facts and y > FL + 54:
        doc.HL(y-4, lw=0.4, col=RULE); y -= SEC_GAP
        y = doc.section_label(y, "BEKRÄFTAD LÄGESBILD", GRN)
        for fact in facts[:4]:
            if y < FL + 12: break
            doc.DOT(ML+5, y+3, 2, GRN)
            y = doc.W(ML+14, y, fact, 9, INK2, BODY,
                      mw=TW-16, lh=13, floor=FL, mx=2)
            y -= 4

    # ── CRITIQUE ──────────────────────────────────────────────────────────────
    verdict = _get_verdict(r)
    if verdict and y > FL + 40:
        doc.HL(y-4, lw=0.4, col=RULE); y -= SEC_GAP
        y = doc.section_label(y, "KRITIK  ·  ALTERNATIV TOLKNING", AMB)
        doc.LBAR(ML+2, y-30, y+2, AMB, 2)
        y = doc.W(ML+10, y, verdict, 9.5, INK2, ITAL,
                  mw=TW-12, lh=14, floor=FL, mx=2)

    # ── FINAL ASSESSMENT ──────────────────────────────────────────────────────
    hero = _get_hero(r)
    if hero and y > FL + 32:
        doc.HL(y-6, lw=0.4, col=RULE); y -= SEC_GAP
        y = doc.section_label(y, "ANALYTISK SLUTBEDÖMNING")
        doc.W(ML, y, hero, 10, INK, BOLD,
              mw=TW, lh=15, floor=FL, mx=2)


# ═══════════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ═══════════════════════════════════════════════════════════════════════════════

def build_pdf(result: dict) -> bytes:
    buf = io.BytesIO()
    try:
        r = result or {}
        d = Doc(buf)
        build_p1(d, r)
        build_p2(d, r)
        build_p3(d, r)
        d.save()
    except Exception as e:
        buf = io.BytesIO()
        c2  = canvas.Canvas(buf, pagesize=A4)
        c2.setFillColor(BG); c2.rect(0,0,W,H,fill=1,stroke=0)
        c2.setFillColor(RED); c2.setFont(BOLD,11)
        c2.drawString(48, H-60, "PDF-export misslyckades")
        c2.setFillColor(INK); c2.setFont(BODY,8)
        c2.drawString(48, H-80, str(e)[:100])
        c2.save()
    return buf.getvalue()
