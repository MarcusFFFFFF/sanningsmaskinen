import re
import traceback
import streamlit as st
import textwrap

from engine import run_full_pipeline
from normalizer import normalize_result, normalize_references
from pdf_export import build_pdf

st.set_page_config(
    page_title="Sanningsmaskinen",
    page_icon="🧠",
    layout="wide",
)

# -------------------------
# THEME
# -------------------------
ACCENT = "#4ec994"
BG = "#0b111a"
PANEL = "#0f1722"
PANEL_2 = "#0c121a"
PANEL_3 = "#101827"
BORDER = "#2a3441"
TEXT = "#f5f7fb"
MUTED = "#aab4c3"
DANGER = "#ff6b6b"

st.markdown(f"""
<style>
html, body, .stApp {{
    background: {BG};
    color: {TEXT};
}}
.block-container {{
    max-width: 1100px;
}}
.hero {{
    background: {PANEL};
    padding: 30px;
    border-radius: 18px;
    border: 1px solid {BORDER};
}}
.card {{
    background: {PANEL_2};
    padding: 20px;
    border-radius: 16px;
    border: 1px solid {BORDER};
    margin-bottom: 15px;
}}
.red {{
    background: rgba(255, 107, 107, 0.08);
    border: 1px solid rgba(255, 107, 107, 0.3);
}}
.small-muted {{
    color: {MUTED};
    font-size: 12px;
}}
.kicker {{
    color: {ACCENT};
    font-size: 12px;
    letter-spacing: 0.08em;
    font-weight: 700;
    margin-bottom: 10px;
}}
.badge {{
    display: inline-block;
    padding: 6px 10px;
    border-radius: 999px;
    border: 1px solid {BORDER};
    background: {PANEL_3};
    font-size: 12px;
    margin-right: 8px;
    margin-bottom: 8px;
}}
.badge-primary {{
    background: rgba(78, 201, 148, 0.12);
    border-color: rgba(78, 201, 148, 0.35);
}}
a {{
    color: #9fd4ff !important;
}}

/* Button & Input alignment */
.stColumn [data-testid="stButton"] {{
    margin-top: 30px;
}}
.stButton button {{
    width: 100%;
    background: {ACCENT} !important;
    color: {PANEL} !important;
    font-weight: 600;
    border: none !important;
    border-radius: 8px;
    height: 40px;
    transition: all 0.2s;
}}
.stButton button:hover {{
    background: #42b380 !important;
    box-shadow: 0 4px 12px rgba(78, 201, 148, 0.3);
}}
.stTextInput input {{
    border-radius: 8px;
    border: 1px solid {BORDER} !important;
    background: {PANEL_2} !important;
    color: {TEXT} !important;
    height: 40px !important;
}}

/* Ny demo-styling för wow/aha */
.exec-conclusion {{
    font-family: 'Georgia', serif;
    font-size: 1.2rem;
    font-weight: 600;
    color: #b8e8c8;
    line-height: 1.55;
    padding: 1rem 1.2rem;
    border-left: 4px solid #57c78a;
    background: #0a1711;
    margin: 1rem 0;
}}
.zone {{
    border: 1px solid {BORDER};
    margin: 0.5rem 0;
    overflow: hidden;
    background: {PANEL_2};
}}
.zone-header {{
    font-family: 'Courier New', monospace;
    font-size: 0.6rem;
    font-weight: 600;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    padding: 0.6rem 1rem;
    background: {PANEL};
    border-bottom: 1px solid {BORDER};
    color: #aab4c3;
}}
.zone-body {{
    padding: 1rem;
    background: {PANEL_2};
}}
.hyp-dashboard {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1px;
    background: {BORDER};
    border-top: 1px solid {BORDER};
    margin: 1rem 0;
}}
.hyp-card {{
    background: {PANEL_2};
    padding: 1rem;
    position: relative;
    overflow: hidden;
}}
.hyp-card-winner {{
    border-left: 3px solid #57c78a;
}}
.hyp-card-2 {{
    border-left: 3px solid #e2b04c;
}}
.hyp-card-3 {{
    border-left: 3px solid #2a3441;
}}
.hyp-card-key {{
    font-family: 'Courier New', monospace;
    font-size: 0.8rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    margin-bottom: 0.5rem;
    color: {TEXT};
}}
.hyp-card-title {{
    font-family: 'Georgia', serif;
    font-size: 1rem;
    font-weight: 600;
    color: {TEXT};
    line-height: 1.45;
    margin-bottom: 0.8rem;
}}
.hyp-card-bar-track {{
    flex: 1;
    height: 6px;
    background: #0f1722;
    border-radius: 3px;
    position: relative;
}}
.hyp-card-bar-fill {{
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    border-radius: 3px;
}}
.pa-sec-lbl {{
    font-family: 'Courier New', monospace;
    font-size: 0.55rem;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    margin: 0.8rem 0 0.2rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #57c78a;
}}
.pa-sec-lbl::before {{
    content: '';
    display: inline-block;
    width: 14px;
    height: 1px;
    background: #57c78a;
    flex-shrink: 0;
}}
.pa-sec-body {{
    font-family: 'Arial', sans-serif;
    font-size: 0.9rem;
    line-height: 1.7;
    margin-bottom: 0.5rem;
    padding: 0.5rem 1rem;
    border-left: 2px solid #2a3441;
    background: {PANEL};
}}
</style>
""", unsafe_allow_html=True)

# -------------------------
# STATE
# -------------------------
for key, default in {
    "query": "",
    "last_raw": None,
    "last_norm": None,
    "last_ui": None,
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

# -------------------------
# HELPERS
# -------------------------
def _clean(x):
    if x is None:
        return ""
    return str(x).strip()

def _pick(d, *keys, default=None):
    if not isinstance(d, dict):
        return default
    for k in keys:
        if k in d and d[k] not in (None, "", [], {}):
            return d[k]
    return default

def _to_pct(v, default=0):
    try:
        if v is None:
            return default
        if isinstance(v, str):
            v = v.replace("%", "").strip()
        v = float(v)
        if v <= 1:
            v *= 100
        return max(0, min(100, int(round(v))))
    except Exception:
        return default

def _to_list(x):
    if x is None:
        return []
    if isinstance(x, list):
        return [str(i).strip() for i in x if str(i).strip()]
    if isinstance(x, str):
        lines = [re.sub(r"^[-•*\d\.\)\s]+", "", s).strip() for s in x.splitlines()]
        return [s for s in lines if s]
    return [str(x).strip()]

def _truncate(s, n=180):
    s = _clean(s)
    if len(s) <= n:
        return s
    cut = s[:n]
    if " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut + "…"

def _extract_links(*texts):
    found = []
    seen = set()
    md_pat = re.compile(r'\[([^\]]+)\]\((https?://[^\)]+)\)')
    url_pat = re.compile(r'https?://[^\s\)\]]+')
    for t in texts:
        if not t:
            continue
        for title, url in md_pat.findall(str(t)):
            key = (title.strip(), url.strip())
            if key not in seen:
                seen.add(key)
                found.append(key)
        # raw urls if no markdown label
        for url in url_pat.findall(str(t)):
            if not any(url == u for _, u in found):
                label = re.sub(r'^https?://(www\.)?', '', url).split('/')[0]
                key = (label, url)
                if key not in seen:
                    seen.add(key)
                    found.append(key)
    return found[:10]

def adapt_result(raw, norm, query):
    current = norm.get("claude_revised") or norm.get("claude") or {}
    hyps = current.get("hypotheses", []) or []
    hyps_out = []
    for i, h in enumerate(hyps[:3], start=1):
        hyps_out.append({
            "id": h.get("key", f"H{i}"),
            "label": h.get("label", "HYPOTES"),
            "score": _to_pct(h.get("conf_pct", h.get("conf", 0))),
            "title": h.get("title") or h.get("label") or f"H{i}",
            "summary": _truncate(h.get("tes", ""), 150),
        })
    while len(hyps_out) < 3:
        i = len(hyps_out) + 1
        hyps_out.append({
            "id": f"H{i}",
            "label": "HYPOTES",
            "score": 0,
            "title": "Ej tillgänglig",
            "summary": "",
        })

    top = hyps_out[0] if hyps_out else {"id":"H1","score":0}
    summary = _clean(current.get("sammanfattning"))
    ranking = _to_list(current.get("ranking"))
    gf = _to_list(current.get("grundfakta"))
    hero = ranking[0] if ranking else (summary or _truncate(raw.get("article",""), 180) or "Ingen tydlig slutsats genererades.")
    insight = summary or (ranking[1] if len(ranking) > 1 else "Ingen nyckelinsikt kunde extraheras.")
    if hero == insight and len(ranking) > 1:
        insight = ranking[1]

    # primary/revised
    primary_analysis = gf[:3] if gf else ([summary] if summary else [])
    revised_text = _clean(norm.get("revised_text"))
    revised_source = _to_list(revised_text)[:3] if revised_text else []
    if not revised_source:
        revised_source = _to_list(raw.get("final_analysis"))[:3]
    red = norm.get("red", {})
    red_verdict = _clean(red.get("verdict", "Red Team"))
    red_summary = _clean(red.get("varfor_fel") or red.get("verdict") or "")

    rc = raw.get("reality_check", {}) or {}
    rc_text = _clean(rc.get("text"))
    breaking = []
    for line in rc_text.splitlines():
        s = line.strip()
        if s.startswith("CLAIM "):
            parts = s.split("|")
            claim = parts[0].split(":",1)[-1].strip()
            if claim:
                breaking.append(_truncate(claim, 95))
        if len(breaking) >= 3:
            break
    if not breaking:
        claude_answer = raw.get("claude_answer","")
        for line in claude_answer.splitlines():
            s=line.strip()
            if s.startswith("BREAKING") or "SENASTE TIMMARNAS" in s.upper():
                continue
            if s.startswith("1.") or s.startswith("2.") or s.startswith("3.") or s.startswith("4."):
                breaking.append(_truncate(re.sub(r'^\d+\.\s*', '', s), 95))
            if len(breaking)>=3:
                break

    sources = _extract_links(
        raw.get("claude_answer",""),
        raw.get("final_analysis",""),
        raw.get("gpt_answer",""),
        raw.get("red_team_report",""),
    )

    snapshot = {
        "Kontroll": top["title"],
        "Status": rc.get("status", raw.get("status","PÅGÅENDE")),
        "Risk": "Medel" if rc.get("status") in ("PARTIAL","ONGOING","KLAR","REVIDERAD") else "Hög",
        "Påverkan": top["label"],
    }

    return {
        "question": query,
        "headline": hero,
        "confidence": top["score"] or 65,
        "insight": insight,
        "h": [(h["id"], h["label"], h["score"], h["title"]) for h in hyps_out],
        "primary": primary_analysis or ["Primär analys ej tillgänglig."],
        "revised": revised_source or ["Ingen reviderad analys genererades."],
        "red": red_summary or "Ingen Red Team-sammanfattning tillgänglig.",
        "sources": sources or [("Inga klickbara källor extraherades", "#")],
        "raw": raw,
        "norm": norm,
        "snapshot": snapshot,
        "breaking": breaking,
        "red_title": red_verdict,
    }

def run_analysis(query):
    raw = run_full_pipeline(query)
    norm = normalize_result(raw)
    ui = adapt_result(raw, norm, query)
    return raw, norm, ui

# -------------------------
# UI
# -------------------------
st.title("Sanningsmaskinen")

st.markdown("""
<div class='hero'>
<h2>Förstå komplexa frågor på minuter</h2>
<p style='color:#aab4c3'>Analyserar hypoteser, evidens och konflikter.</p>
</div>
""", unsafe_allow_html=True)

col1, col2 = st.columns([5,1])
with col1:
    q = st.text_input("Fråga", value=st.session_state.query, key="query_input")
with col2:
    run = st.button("Analysera", key="run_btn")

if run and q:
    st.session_state.query = q
    try:
        with st.spinner("Kör analyskedjan…"):
            raw, norm, ui = run_analysis(q)
        st.session_state.last_raw = raw
        st.session_state.last_norm = norm
        st.session_state.last_ui = ui
    except Exception as e:
        st.error(f"Analysen misslyckades: {e}")
        st.code(traceback.format_exc())

if st.session_state.last_ui:
    r = st.session_state.last_ui

    # Wow: Premium hero med fråga
    st.markdown(f"""
    <div class="hero">
        <div class="kicker">SANNINGSMASKINEN</div>
        <h1>{r["question"]}</h1>
        <p>AI-driven analys av påståenden med konkurrerande hypoteser och adversariell kritik.</p>
    </div>
    """, unsafe_allow_html=True)

    # Aha: Beslutslager högst upp
    st.markdown(f"""
    <div class="exec-conclusion">
        <div class="small-muted">SLUTSATS</div>
        {r['headline']}
    </div>
    """, unsafe_allow_html=True)

    # Confidence och insight
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown("**Säkerhet i analysen**")
        st.progress(r["confidence"])
        st.write(f"{r['confidence']}%")
    with col2:
        st.markdown("**Nyckelinsikt**")
        st.write(r["insight"])

    # H1/H2/H3 Dashboard
    st.markdown("<div class='zone'><div class='zone-header'>HYPOTESER — Konkurrerande förklaringar</div><div class='zone-body'>", unsafe_allow_html=True)
    st.markdown("<div class='hyp-dashboard'>", unsafe_allow_html=True)
    for i, (id_, label, score, title) in enumerate(r["h"]):
        card_class = "hyp-card"
        if i == 0:
            card_class += " hyp-card-winner"
        elif i == 1:
            card_class += " hyp-card-2"
        else:
            card_class += " hyp-card-3"
        bar_color = "#57c78a" if i == 0 else "#e2b04c" if i == 1 else "#2a3441"
        st.markdown(f"""
        <div class="{card_class}">
            <div class="hyp-card-key">{id_}</div>
            <div class="hyp-card-title">{title}</div>
            <div style="display: flex; align-items: center; gap: 0.6rem; margin-bottom: 0.5rem;">
                <div class="hyp-card-bar-track">
                    <div class="hyp-card-bar-fill" style="width: {score*100}%; background: {bar_color};"></div>
                </div>
                <div style="font-family: 'Courier New', monospace; font-size: 0.8rem; font-weight: 700;">{int(score*100)}%</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
    st.markdown("</div></div></div>", unsafe_allow_html=True)

    # Snapshot och breaking i zoner
    colA, colB = st.columns([1.2, 1], gap="medium")
    with colA:
        st.markdown("<div class='zone'><div class='zone-header'>SNAPSHOT — Nuvarande läge</div><div class='zone-body'>", unsafe_allow_html=True)
        for k, v in r["snapshot"].items():
            st.markdown(f"<strong>{k}:</strong> {v}<br>", unsafe_allow_html=True)
        st.markdown("</div></div>", unsafe_allow_html=True)
    with colB:
        st.markdown("<div class='zone'><div class='zone-header'>SENASTE TIMMARNA — Brytningar</div><div class='zone-body'>", unsafe_allow_html=True)
        for item in r["breaking"]:
            st.markdown(f"• {item}")
        st.markdown("</div></div>", unsafe_allow_html=True)

    # Primär och reviderad analys i färgkodade sektioner
    st.markdown("<div class='zone'><div class='zone-header'>ANALYS — Djupdykning</div><div class='zone-body'>", unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("<div class='pa-sec-lbl'>Primär analys</div>", unsafe_allow_html=True)
        st.markdown("<div class='pa-sec-body'>", unsafe_allow_html=True)
        for p in r["primary"]:
            st.write("•", p)
        st.markdown("</div>", unsafe_allow_html=True)
    with col2:
        st.markdown("<div class='pa-sec-lbl'>Reviderad analys</div>", unsafe_allow_html=True)
        st.markdown("<div class='pa-sec-body'>", unsafe_allow_html=True)
        for p in r["revised"]:
            st.write("•", p)
        st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("</div></div>", unsafe_allow_html=True)

    # Red Team i röd zon
    st.markdown("<div class='zone' style='border-left: 4px solid #db6b57;'><div class='zone-header'>RED TEAM — Adversariell kritik</div><div class='zone-body'>", unsafe_allow_html=True)
    st.markdown(f"<strong>{r.get('red_title','Red Team')}</strong><br>{r['red']}", unsafe_allow_html=True)
    st.markdown("</div></div>", unsafe_allow_html=True)

    # Källor och export i expander
    with st.expander("Källor och export", expanded=False):
        st.markdown("### Källor")
        for name, link in r["sources"]:
            if link and link != "#":
                st.markdown(f"- [{name}]({link})")
            else:
                st.markdown(f"- {name}")

        # Export
        try:
            pdf_bytes = build_pdf(st.session_state.last_raw)
            st.download_button(
                "Ladda ner PDF-brief",
                pdf_bytes,
                file_name="sanningsmaskinen_brief.pdf",
                mime="application/pdf",
                key="download_pdf_btn"
            )
        except Exception as e:
            st.warning(f"PDF-export misslyckades: {e}")

        export_text = textwrap.dedent(f"""
        Fråga: {r['question']}
        Slutsats: {r['headline']}
        Säkerhet: {r['confidence']}%

        Primär analys:
        - """ + "\n- ".join(r["primary"]) + """

        Reviderad analys:
        - """ + "\n- ".join(r["revised"]) + f"""

        Red Team:
        {r['red_title']}
        {r['red']}
        """).strip()

        st.download_button(
            "Ladda ner textbriefing",
            export_text,
            file_name="sanningsmaskinen_brief.txt",
            key="download_txt_btn"
        )

    with st.expander("Visa rå analyskedja", expanded=False):
        st.markdown("#### Reality check")
        st.text(st.session_state.last_raw.get("reality_check", {}).get("text", ""))
        st.markdown("#### Claude")
        st.text(st.session_state.last_raw.get("claude_answer", ""))
        st.markdown("#### GPT-kritik")
        st.text(st.session_state.last_raw.get("gpt_answer", ""))
        st.markdown("#### Konfliktrapport")
        st.text(st.session_state.last_raw.get("conflict_report", ""))
        st.markdown("#### Red Team rapport")
        st.text(st.session_state.last_raw.get("red_team_report", ""))
