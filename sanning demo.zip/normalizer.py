# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import Any, Dict, List

# =========================
# Helpers
# =========================

def _clean(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip()

def _lines(x: Any) -> List[str]:
    s = _clean(x)
    if not s:
        return []
    return [ln.strip() for ln in s.splitlines() if ln.strip()]

def _short(text: str, limit: int = 220) -> str:
    text = _clean(text)
    if len(text) <= limit:
        return text
    cut = text[:limit]
    if " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut + "…"

def _to_pct(v: Any, default: int = 0) -> int:
    try:
        if v is None:
            return default
        if isinstance(v, str):
            v = v.replace("%", "").replace(",", ".").strip()
        n = float(v)
        if n <= 1:
            n *= 100
        n = int(round(n))
        return max(0, min(100, n))
    except Exception:
        return default

def _dedupe(items: List[str]) -> List[str]:
    out = []
    seen = set()
    for item in items:
        norm = re.sub(r"\s+", " ", _clean(item)).lower()
        if norm and norm not in seen:
            seen.add(norm)
            out.append(_clean(item))
    return out

def _first_meaningful_sentence(text: str) -> str:
    text = re.sub(r"\s+", " ", _clean(text))
    if not text:
        return ""
    parts = re.split(r"(?<=[\.\!\?])\s+", text)
    for p in parts:
        p = p.strip(" -•")
        if len(p) >= 35:
            return p
    return text

def _extract_links(*texts: str) -> List[Dict[str, str]]:
    md_pat = re.compile(r"\[([^\]]+)\]\((https?://[^\)]+)\)")
    url_pat = re.compile(r"https?://[^\s\)\]]+")
    dom_pat = re.compile(r"\b([a-z0-9.-]+\.[a-z]{2,})(?:/[^\s]*)?", re.I)
    out = []
    seen = set()
    for text in texts:
        t = _clean(text)
        if not t:
            continue
        for title, url in md_pat.findall(t):
            key = (title.strip(), url.strip())
            if key not in seen:
                seen.add(key)
                out.append({"title": title.strip(), "url": url.strip()})
        for url in url_pat.findall(t):
            title = re.sub(r"^https?://(www\.)?", "", url).split("/")[0]
            key = (title, url)
            if key not in seen:
                seen.add(key)
                out.append({"title": title, "url": url})
        for dom in dom_pat.findall(t):
            url = f"https://{dom}"
            key = (dom, url)
            if key not in seen:
                seen.add(key)
                out.append({"title": dom, "url": url})
    return out[:20]

def normalize_references(source: Any) -> List[Dict[str, str]]:
    if isinstance(source, dict):
        texts = [
            _clean(source.get("claude_answer")),
            _clean(source.get("final_analysis")),
            _clean(source.get("gpt_answer")),
            _clean(source.get("conflict_report")),
            _clean(source.get("red_team_report")),
            _clean((source.get("reality_check") or {}).get("text")),
        ]
        return _extract_links(*texts)
    return _extract_links(_clean(source))

# =========================
# Extraction helpers
# =========================

def _extract_section(text: str, starts: List[str], ends: List[str]) -> str:
    if not text:
        return ""
    lower = text.lower()
    start_positions = []
    for s in starts:
        i = lower.find(s.lower())
        if i >= 0:
            start_positions.append(i)
    if not start_positions:
        return ""
    start = min(start_positions)
    end = len(text)
    for e in ends:
        i = lower.find(e.lower(), start + 1)
        if i >= 0:
            end = min(end, i)
    return text[start:end].strip()

def _extract_bullets(text: str) -> List[str]:
    bullets = []
    for ln in _lines(text):
        cleaned = re.sub(r"^[-•*\d\)\.]+\s*", "", ln).strip()
        if cleaned:
            bullets.append(cleaned)
    return _dedupe(bullets)

def _fallback_sentences(text: str, n: int = 4) -> List[str]:
    text = re.sub(r"\s+", " ", _clean(text))
    if not text:
        return []
    parts = re.split(r"(?<=[\.\!\?])\s+", text)
    out = []
    for p in parts:
        p = p.strip(" -•")
        if len(p) >= 35 and not p.lower().startswith(("http", "source:", "källor")):
            out.append(_short(p, 180))
        if len(out) >= n:
            break
    return _dedupe(out)

def _guess_status(raw: Dict[str, Any]) -> str:
    txt = _clean((raw.get("reality_check") or {}).get("text"))
    low = txt.lower()
    if any(k in low for k in ["bekräftad", "confirmed", "[fakta]"]):
        return "BEKRÄFTAD"
    if any(k in low for k in ["ongoing", "pågående", "utredning"]):
        return "PÅGÅENDE"
    return "PÅGÅENDE"

# =========================
# Hypothesis extraction
# =========================

DEFAULT_HYP = [
    {"key": "H1", "label": "STRUKTURELL", "title": "Ej tillgänglig", "conf_pct": 0, "tes": "", "is_fallback": False},
    {"key": "H2", "label": "INRIKESPOLITIK", "title": "Ej tillgänglig", "conf_pct": 0, "tes": "", "is_fallback": False},
    {"key": "H3", "label": "AKTÖRSPSYKOLOGI", "title": "Ej tillgänglig", "conf_pct": 0, "tes": "", "is_fallback": False},
]

def _extract_hypotheses(text: str) -> List[Dict[str, Any]]:
    hyps = {h["key"]: dict(h) for h in DEFAULT_HYP}
    if not text:
        return [hyps["H1"], hyps["H2"], hyps["H3"]]

    # Flexible pattern search for H1/H2/H3 blocks
    lines = _lines(text)
    for i, ln in enumerate(lines):
        key = ln.strip().upper()
        if key in ("H1", "H2", "H3"):
            h = hyps[key]
            # find score nearby
            for j in range(i, min(i + 8, len(lines))):
                m = re.search(r"(\d{1,3})\s*%", lines[j])
                if m:
                    h["conf_pct"] = _to_pct(m.group(1))
                    break
            # find label/title nearby
            candidates = []
            for j in range(i + 1, min(i + 5, len(lines))):
                cand = lines[j].strip("•- ")
                if cand and not re.search(r"\d+%", cand):
                    candidates.append(cand)
            if candidates:
                h["label"] = candidates[0].upper()[:48]
            if len(candidates) > 1:
                h["title"] = _short(candidates[1], 80)
            if len(candidates) > 2:
                h["tes"] = _short(candidates[2], 180)

    # Secondary inference from keywords if still empty
    keyword_buckets = {
        "H1": ["strukturell", "maktbalans", "resurser", "system"],
        "H2": ["inrikespolitik", "domestic politics", "koalition", "valintressen", "inrikes"],
        "H3": ["aktörspsykologi", "världsbild", "psykologi", "individuella beslut", "zaluzjnyj"],
    }
    for key, kws in keyword_buckets.items():
        h = hyps[key]
        if h["title"] != "Ej tillgänglig" and h["conf_pct"] > 0:
            continue
        for ln in lines:
            low = ln.lower()
            if any(kw in low for kw in kws):
                if h["title"] == "Ej tillgänglig":
                    h["title"] = _short(ln, 80)
                if not h["tes"] and len(ln) > 35:
                    h["tes"] = _short(ln, 180)
                h["is_fallback"] = True
                break

    # Final fallback from ranking hints in text
    for key in ("H1", "H2", "H3"):
        h = hyps[key]
        if h["title"] == "Ej tillgänglig":
            h["is_fallback"] = True
            if key == "H1":
                h["title"] = "Primär hypotes"
                h["conf_pct"] = max(h["conf_pct"], 55)
            elif key == "H2":
                h["title"] = "Sekundär hypotes"
                h["conf_pct"] = max(h["conf_pct"], 35)
            else:
                h["title"] = "Tertiär hypotes"
                h["conf_pct"] = max(h["conf_pct"], 20)
        if not h["tes"]:
            h["tes"] = h["title"]

    return [hyps["H1"], hyps["H2"], hyps["H3"]]

# =========================
# Main normalize
# =========================

def normalize_result(raw: Dict[str, Any]) -> Dict[str, Any]:
    raw = raw or {}

    claude = _clean(raw.get("claude_answer"))
    final_analysis = _clean(raw.get("final_analysis"))
    gpt = _clean(raw.get("gpt_answer"))
    conflict = _clean(raw.get("conflict_report"))
    red_team_report = _clean(raw.get("red_team_report"))
    article = _clean(raw.get("article"))
    reality_text = _clean((raw.get("reality_check") or {}).get("text"))

    combined = "\n\n".join([claude, final_analysis, conflict, gpt, red_team_report, article])

    # Summary / headline candidate
    summary_section = _extract_section(
        final_analysis or claude,
        ["analytisk slutbedömning", "slutsats", "bedömning", "quick answer"],
        ["djupanalys", "källor", "h1", "möjliga utfall"]
    )
    summary = _first_meaningful_sentence(summary_section) or _first_meaningful_sentence(final_analysis) or _first_meaningful_sentence(claude) or _first_meaningful_sentence(article)
    summary = _short(summary, 260)

    # Primary analysis
    primary_section = _extract_section(
        combined,
        ["grundfakta", "bakgrund", "bekräftad lägesbild", "faktapåståenden", "bakgrund & kontext"],
        ["möjliga utfall", "hypotesanalys", "reviderad", "red team", "källor"]
    )
    primary_bullets = _extract_bullets(primary_section)
    primary_is_fallback = False
    if not primary_bullets:
        primary_bullets = _fallback_sentences(article or final_analysis or claude, 4)
        primary_is_fallback = True

    # Revised analysis
    revised_section = _extract_section(
        conflict or gpt or final_analysis,
        ["avgörande", "reviderad bedömning", "reviderad analys", "konfliktrapport", "konflikt 1"],
        ["red team", "källor"]
    )
    revised_bullets = _extract_bullets(revised_section)
    revised_is_fallback = False
    if not revised_bullets:
        revised_bullets = _fallback_sentences(conflict or gpt or final_analysis, 4)
        revised_is_fallback = True

    # Red team
    red_verdict = ""
    for ln in _lines(red_team_report):
        if any(k in ln.lower() for k in ["verdict", "kritik", "modifieras", "kollapsar", "håller", "red team"]):
            red_verdict = _short(ln, 120)
            break
    red_summary = _first_meaningful_sentence(red_team_report)
    red_is_fallback = False
    if not red_summary:
        red_summary = "Ingen fullständig Red Team-sammanfattning kunde extraheras ur rå output."
        red_is_fallback = True
    if "kunde inte slutföra" in red_team_report.lower():
        red_summary = "Red Team kunde inte slutföra sin analys. Behandla primärhypotesen med lägre konfidens tills ny körning verifierar resultatet."
        red_is_fallback = False

    # Hypotheses
    hyps = _extract_hypotheses(combined)
    ranking = [f"{h['key']} ({h['label']}): {h['title']} — {h['conf_pct']}%" for h in sorted(hyps, key=lambda x: x.get('conf_pct', 0), reverse=True)]

    # References
    refs = normalize_references(raw)

    # Reality check
    rc = {
        "text": reality_text,
        "status": _guess_status(raw),
    }

    parse_notes = []
    if primary_is_fallback:
        parse_notes.append("Primär analys extraherades via fallback från narrativ text.")
    if revised_is_fallback:
        parse_notes.append("Reviderad analys extraherades via fallback från konflikt-/GPT-text.")
    if red_is_fallback:
        parse_notes.append("Red Team sammanfattning saknade tydlig struktur och extraherades via fallback.")
    if any(h.get("is_fallback") for h in hyps):
        parse_notes.append("En eller flera hypoteser extraherades via fallback och bör läsas med lägre parser-säkerhet.")

    extraction_confidence = "hög"
    if len(parse_notes) >= 3:
        extraction_confidence = "låg"
    elif parse_notes:
        extraction_confidence = "medel"

    return {
        "question": _clean(raw.get("question")),
        "references": refs,
        "reality_check": rc,
        "red": {
            "verdict": red_verdict or "RED TEAM",
            "varfor_fel": _short(red_summary, 220),
            "is_fallback": red_is_fallback,
        },
        "revised_text": "\n".join(revised_bullets),
        "claude": {
            "sammanfattning": summary,
            "ranking": ranking,
            "grundfakta": primary_bullets,
            "hypotheses": hyps,
        },
        "claude_revised": {
            "sammanfattning": summary,
            "ranking": ranking,
            "grundfakta": primary_bullets,
            "hypotheses": hyps,
        },
        "parse_notes": parse_notes,
        "extraction_confidence": extraction_confidence,
    }
